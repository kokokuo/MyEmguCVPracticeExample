﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//EmguCV
using Emgu.CV;
using Emgu.Util;
using Emgu.CV.Util;
using Emgu.CV.UI;
using Emgu.CV.Structure;
using Emgu.CV.CvEnum;
using System.IO;
namespace HelloHistogramForm
{
    public partial class Form1 : Form
    {
        //取得專案執行黨所在的目錄=>System.Windows.Forms.Application.StartupPath
        //使用DirectoryInfo移動至上層
        DirectoryInfo dir;
        Image<Bgr, byte> loadImg;
        string imgPath;
        public Form1()
        {
            InitializeComponent();
            dir = new DirectoryInfo(System.Windows.Forms.Application.StartupPath);
        }


        private string loadImgFile()
        {
            OpenFileDialog dlg = new OpenFileDialog();
            //移動上層在指定下層路徑
            dlg.RestoreDirectory = true;
            dlg.InitialDirectory = dir.Parent.Parent.FullName + @"\ModelImages";
            dlg.Title = "Open Image File";
           
            // Set filter for file extension and default file extension
            dlg.Filter = "JPeg Image|*.jpg|Bitmap Image|*.bmp|Gif Image|*.gif|Png Image|*.png";

            // Display OpenFileDialog by calling ShowDialog method ->ShowDialog()
            // Get the selected file name and display in a TextBox
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK && dlg.FileName != null)
            {
                // Open document
                string filename = dlg.FileName;
                return filename;
            }
            else
            {
                return null;
            }

        }
       

        private void loadImgButton_Click(object sender, EventArgs e)
        {

            imgPath = loadImgFile(); //圖片路徑的字串值
            loadImg = new Image<Bgr, byte>(imgPath);
            //顯示圖片
            ImageViewer viewer = new ImageViewer(loadImg, "Loaded Image");
            viewer.Show(this);

            //1.使用HistogramViewer
            HistogramViewer.Show(loadImg[0], 32);　//image[0] 顯示Blue,bin = 32
            HistogramViewer.Show(loadImg, 32);　//顯示所有通道

            //2.使用HistogramBox
            imgHistogramBox.GenerateHistograms(loadImg, 32);
            imgHistogramBox.Refresh(); //更新資料
            imgHistogramBox.Show(); 
        }

        
    }
}
