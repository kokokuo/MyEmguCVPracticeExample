This is a histogram save and load example
using Binary,SOAP serialization can success,but xml will be failed.