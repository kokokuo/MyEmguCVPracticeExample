﻿namespace HelloSaveAndReadHistogram
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.loadImgButton = new System.Windows.Forms.Button();
            this.imgHistogramBox = new Emgu.CV.UI.HistogramBox();
            this.saveHistButton = new System.Windows.Forms.Button();
            this.saveHistTextBox = new System.Windows.Forms.TextBox();
            this.loadHistButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // loadImgButton
            // 
            this.loadImgButton.Location = new System.Drawing.Point(18, 22);
            this.loadImgButton.Name = "loadImgButton";
            this.loadImgButton.Size = new System.Drawing.Size(75, 23);
            this.loadImgButton.TabIndex = 3;
            this.loadImgButton.Text = "載入圖片";
            this.loadImgButton.UseVisualStyleBackColor = true;
            this.loadImgButton.Click += new System.EventHandler(this.loadImgButton_Click);
            // 
            // imgHistogramBox
            // 
            this.imgHistogramBox.Location = new System.Drawing.Point(18, 67);
            this.imgHistogramBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.imgHistogramBox.Name = "imgHistogramBox";
            this.imgHistogramBox.Size = new System.Drawing.Size(360, 265);
            this.imgHistogramBox.TabIndex = 2;
            // 
            // saveHistButton
            // 
            this.saveHistButton.Location = new System.Drawing.Point(13, 378);
            this.saveHistButton.Name = "saveHistButton";
            this.saveHistButton.Size = new System.Drawing.Size(118, 23);
            this.saveHistButton.TabIndex = 4;
            this.saveHistButton.Text = "儲存值方圖";
            this.saveHistButton.UseVisualStyleBackColor = true;
            this.saveHistButton.Click += new System.EventHandler(this.saveHistButton_Click);
            // 
            // saveHistTextBox
            // 
            this.saveHistTextBox.Location = new System.Drawing.Point(147, 378);
            this.saveHistTextBox.Name = "saveHistTextBox";
            this.saveHistTextBox.Size = new System.Drawing.Size(100, 25);
            this.saveHistTextBox.TabIndex = 5;
            // 
            // loadHistButton
            // 
            this.loadHistButton.Location = new System.Drawing.Point(253, 22);
            this.loadHistButton.Name = "loadHistButton";
            this.loadHistButton.Size = new System.Drawing.Size(132, 23);
            this.loadHistButton.TabIndex = 6;
            this.loadHistButton.Text = "載入值方圖資料";
            this.loadHistButton.UseVisualStyleBackColor = true;
            this.loadHistButton.Click += new System.EventHandler(this.loadHistButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 461);
            this.Controls.Add(this.loadHistButton);
            this.Controls.Add(this.saveHistTextBox);
            this.Controls.Add(this.saveHistButton);
            this.Controls.Add(this.loadImgButton);
            this.Controls.Add(this.imgHistogramBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button loadImgButton;
        private Emgu.CV.UI.HistogramBox imgHistogramBox;
        private System.Windows.Forms.Button saveHistButton;
        private System.Windows.Forms.TextBox saveHistTextBox;
        private System.Windows.Forms.Button loadHistButton;
    }
}

