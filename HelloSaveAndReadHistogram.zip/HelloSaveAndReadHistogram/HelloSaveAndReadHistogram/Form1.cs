﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//EmguCV
using Emgu.CV;
using Emgu.Util;
using Emgu.CV.Util;
using Emgu.CV.UI;
using Emgu.CV.Structure;
using Emgu.CV.CvEnum;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Soap;

namespace HelloSaveAndReadHistogram
{
    public partial class Form1 : Form
    {
        DirectoryInfo dir;
        Image<Bgr, byte> loadImg;
        string openFileName;
        DenseHistogram imgHist;
        ImageViewer viewer;
        public Form1()
        {
            InitializeComponent();
            
            dir = new DirectoryInfo(System.Windows.Forms.Application.StartupPath);
        }

     

        private string OpenLoadImgFile()
        {
            OpenFileDialog dlg = new OpenFileDialog();
            //移動上層在指定下層路徑
            dlg.RestoreDirectory = true;
            dlg.InitialDirectory = dir.Parent.Parent.FullName + @"\ModelImages";
            dlg.Title = "Open Image File";

            // Set filter for file extension and default file extension
            dlg.Filter = "JPeg Image|*.jpg|Bitmap Image|*.bmp|Gif Image|*.gif|Png Image|*.png";

            // Display OpenFileDialog by calling ShowDialog method ->ShowDialog()
            // Get the selected file name and display in a TextBox
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK && dlg.FileName != null)
            {
                // Open document
                string filename = dlg.FileName;
                return filename;
            }
            else
            {
                return null;
            }

        }
        private string OpenSavedgHistogramDataFile()
        {
            OpenFileDialog dlg = new OpenFileDialog();
            //移動上層在指定下層路徑
            dlg.RestoreDirectory = true;
            dlg.InitialDirectory = dir.Parent.Parent.FullName + @"\SavedHistFile";
            // Set filter for file extension and default file extension
            dlg.Filter = "Binary Files (*.bin)|*.bin|XML Files|*.xml|Soap File|*.soap";
            dlg.Title = "Open HistogramData File";
            // Display OpenFileDialog by calling ShowDialog method ->ShowDialog()
            // Get the selected file name and display in a TextBox
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK && dlg.FileName != null)
            {
                // Open document
                string filename = dlg.FileName;
                return filename;
            }
            else
            {
                return null;
            }
        }

        private DenseHistogram CalHistBlue()
        {
            //計算Blue單通道
            int Bbin = 32; //切割量化的數量
            RangeF BRange = new RangeF(0, 255);
            DenseHistogram blueHist = new DenseHistogram(Bbin, BRange);
            //參數一是要計算的顏色資料，這邊分割通道並取得Blue通道的顏色;依序[1]:Green->[2]:Red
            blueHist.Calculate(new IImage[] { loadImg.Split()[0] }, false, null);
            return blueHist;
        }

        private DenseHistogram CalHistBlueGreenHist()
        {
            //計算Blue-Green單通道
            int[] BGbins = { 16, 16 }; //切割量化的數量
            RangeF[] BGRanges = new RangeF[] { new RangeF(0, 255), new RangeF(0, 255) };
            DenseHistogram bgHist = new DenseHistogram(BGbins, BGRanges);
            //填入Blue-Green通道的顏色圖像
            bgHist.Calculate(new IImage[] { loadImg.Split()[0], loadImg.Split()[1] }, false, null);

            return bgHist;
        }

        private DenseHistogram CalHistHSHist()
        {
            //計算Hsv的H-S
            int[] HSbins = { 8, 16 }; //切割量化的數量{HBin,SBin}
            RangeF[] HSRanges = new RangeF[] { new RangeF(0, 180), new RangeF(0, 255) }; //H,S
            DenseHistogram hsHist = new DenseHistogram(HSbins, HSRanges);
            //填入H-S通道的顏色圖像
            hsHist.Calculate(new IImage[] { loadImg.Convert<Hsv, byte>().Split()[0], loadImg.Convert<Hsv, byte>().Split()[1] }, false, null);

            return hsHist;
        }

        private void loadImgButton_Click(object sender, EventArgs e)
        {

            openFileName = OpenLoadImgFile(); //圖片路徑的字串值
            if (openFileName!= null)
            {
                loadImg = new Image<Bgr, byte>(openFileName);
                //顯示圖片
                viewer = new ImageViewer(loadImg, "Loaded Image");
                viewer.Show(this);

                imgHist = CalHistBlue();
                //2.使用HistogramBox
                imgHistogramBox.AddHistogram("Blue histogram", Color.Blue, imgHist); //放入自己計算的值方圖資料
                imgHistogramBox.Refresh(); //更新資料
                imgHistogramBox.Show();

            }
        }
        //SOAP Serialization-----------------------------------------------------------------------------------
        private void SaveHistToSOAPFile(DenseHistogram histDense, string textFileName)
        {
            Stream stream;
            SoapFormatter soapformatter;
            //寫檔
            try
            {
                // serialize histogram
                stream = File.Open(textFileName + ".soap", FileMode.Create);
                soapformatter = new SoapFormatter();

                soapformatter.Serialize(stream, histDense);
                stream.Close();

            }

            catch (IOException ex)
            {
                throw new InvalidOperationException(ex.Message);

            }
        }
        private DenseHistogram LoadHistSOAPFile(string loadHistFileName)
        {
            Stream stream;
            SoapFormatter soapformatter;
            DenseHistogram histLoaded;
            try
            {
                if (File.Exists(loadHistFileName))
                {
                    stream = File.Open(loadHistFileName, FileMode.Open);
                    soapformatter = new SoapFormatter();
                    histLoaded = (DenseHistogram)soapformatter.Deserialize(stream);
                    stream.Close();
                    return histLoaded;
                }
                return null;

            }
            catch (IOException ex)
            {
                throw new InvalidOperationException(ex.Message);
            }

        }

        //XML Serialization-----------------------------------------------------------------------------------
        private void SaveHistToXMLFile(DenseHistogram histDense, string textFileName)
        {
            Stream stream;
            XmlSerializer xmlformatter;
            //寫檔
            try
            {
                // serialize histogram
                stream = File.Open(textFileName + ".xml", FileMode.Create);
                xmlformatter = new XmlSerializer(typeof(DenseHistogram));
                xmlformatter.Serialize(stream, histDense);
                stream.Close();

            }

            catch (IOException ex)
            {
                throw new InvalidOperationException(ex.Message);

            }
        }
        private DenseHistogram LoadHistXMLFile(string loadHistFileName)
        {
            Stream stream;
            XmlSerializer xmlformatter;
            DenseHistogram histLoaded;
            try
            {
                if (File.Exists(loadHistFileName))
                {
                    stream = File.Open(loadHistFileName, FileMode.Open);
                    xmlformatter = new XmlSerializer(typeof(DenseHistogram));
                    histLoaded = (DenseHistogram)xmlformatter.Deserialize(stream);
                    stream.Close();
                    return histLoaded;
                }
                return null;

            }
            catch (IOException ex)
            {
                throw new InvalidOperationException(ex.Message);
            }

        }
        //Binary Serialization-----------------------------------------------------------------------------------
        private void SaveHistToBinaryFile(DenseHistogram  histDense,string textFileName)
        {
            Stream stream;
            System.Runtime.Serialization.Formatters.Binary.BinaryFormatter bformatter;
            //寫檔
            try
            {
                // serialize histogram
                stream = File.Open(textFileName + ".bin", FileMode.Create);
                bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                bformatter.Serialize(stream, histDense);
                stream.Close();
                
            }

            catch (IOException ex)
            {
                throw new InvalidOperationException(ex.Message);
                
            }
        }

        private DenseHistogram LoadHistBinaryFile(string loadHistFileName) {
            Stream stream;
            System.Runtime.Serialization.Formatters.Binary.BinaryFormatter bformatter;
            DenseHistogram histLoaded;
            try
            {
                if (File.Exists(loadHistFileName))
                {
                    stream = File.Open(loadHistFileName, FileMode.Open);
                    bformatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
                    histLoaded = (DenseHistogram)bformatter.Deserialize(stream);
                    stream.Close();
                    return histLoaded;
                }
                return null;

            }
            catch (IOException ex)
            {
                throw new InvalidOperationException(ex.Message);
            }
        
        }

        private void loadHistButton_Click(object sender, EventArgs e)
        {
            string loadHistFileName = OpenSavedgHistogramDataFile();
            if (loadHistFileName !=null ) {
                //imgHist =  LoadHistBinaryFile(loadHistFileName);
                //XML load will be faild
                //imgHist = LoadHistXMLFile(loadHistFileName);
                imgHist = LoadHistSOAPFile(loadHistFileName);
                HistogramViewer.Show(imgHist, "Loaded Histogram");
            }
        }

        private void saveHistButton_Click(object sender, EventArgs e)
        {
            if (saveHistTextBox.Text.Length > 0 && imgHist != null)
            {
                //SaveHistToBinaryFile(imgHist, saveHistTextBox.Text);
                //XML save will be faild
                SaveHistToXMLFile(imgHist, saveHistTextBox.Text);
                //SaveHistToSOAPFile(imgHist, saveHistTextBox.Text);
                MessageBox.Show("Saved");
            }
            else
            {
                MessageBox.Show("Haven't Calculate Histogram or give save File name");
            }
        }
    }
}
