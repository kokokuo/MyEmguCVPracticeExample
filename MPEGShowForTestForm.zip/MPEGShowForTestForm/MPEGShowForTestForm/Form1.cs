﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Emgu.CV;
using Emgu.CV.UI;
using Emgu.CV.Structure;

namespace MPEGShowForTestForm
{
    public partial class Form1 : Form
    {
        Timer Show_Time = new Timer();        
        Capture capture;
        ImageList imgList;
        int index;
        int FPS = 30;
        List<Image<Bgr, byte>> emguImgList; //emgu structure of list 


        public Form1()
        {
            InitializeComponent();
            emguImgList = new List<Image<Bgr, byte>>();
            imgList = new ImageList();
            imgList.ImageSize = new System.Drawing.Size(256, 144); //Max 256,256

            //change your video filename
            capture = new Capture(@"..\..\Test.mp4"); //create a camera captue
            index = 0;
        }

        private void Show_Timer_Tick(object sender, EventArgs e)
        {
            
            //Emgucv version
            //if (index < emguImgList.Count)
            //{
            //   pictureBox1.Image = emguImgList[index++].ToBitmap();
            //}
            
            //ImageList version
            if(index < imgList.Images.Count){
                pictureBox1.Image = imgList.Images[index++];
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
 
            for (int frame = 0; frame < 500; frame++)
            {
                //ImageList version
                imgList.Images.Add( capture.QueryFrame().Resize(720, 480, Emgu.CV.CvEnum.INTER.CV_INTER_LINEAR).ToBitmap() );
                    
                //Emgucv version
                //emguImgList.Add(new Image<Bgr,byte>(capture.QueryFrame().Resize(720,480,Emgu.CV.CvEnum.INTER.CV_INTER_LINEAR).ToBitmap()));
            }

            Show_Time.Tick += new EventHandler(Show_Timer_Tick);
            Show_Time.Interval = 1000 / FPS;
            Show_Time.Start();
        }
      
    }
}
