This is a query video and show slice of the video by picturebox
this sample just help teacher to test how to show emgu image format on the picturebox control.