﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//EmguCV
using Emgu.CV;
using Emgu.Util;
using Emgu.CV.UI;
using Emgu.CV.Structure;
using Emgu.CV.CvEnum;
using System.IO;
using System.Runtime.InteropServices;
namespace HelloDrawHistogram
{
    public partial class Form1 : Form
    {
        const float h_max_range = 180;
        const float s_max_range = 255;

        //取得專案執行黨所在的目錄=>System.Windows.Forms.Application.StartupPath
        //使用DirectoryInfo移動至上層
        DirectoryInfo dir;
        Image<Bgr, byte> loadImg;
        string imgPath;
        public Form1()
        {
            InitializeComponent();
            dir = new DirectoryInfo(System.Windows.Forms.Application.StartupPath);
        }

        private string loadImgFile()
        {
            OpenFileDialog dlg = new OpenFileDialog();
            //移動上層在指定下層路徑
            dlg.RestoreDirectory = true;
            dlg.InitialDirectory = dir.Parent.Parent.FullName + @"\ModelImages";
            dlg.Title = "Open Image File";

            // Set filter for file extension and default file extension
            dlg.Filter = "JPeg Image|*.jpg|Bitmap Image|*.bmp|Gif Image|*.gif|Png Image|*.png";

            // Display OpenFileDialog by calling ShowDialog method ->ShowDialog()
            // Get the selected file name and display in a TextBox
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK && dlg.FileName != null)
            {
                // Open document
                string filename = dlg.FileName;
                return filename;
            }
            else
            {
                return null;
            }

        }

        private void loadImageButton_Click(object sender, EventArgs e)
        {
            imgPath = loadImgFile(); //圖片路徑的字串值
            if (imgPath != null)
            {
                loadImg = new Image<Bgr, byte>(imgPath);

                //顯示圖片
                ImageViewer viewer = new ImageViewer(loadImg, "Loaded Image");
                viewer.Show(this);

                //calculate histogram
                IntPtr srcImage = loadImg.Copy().Ptr; //ok
                //CvInvoke.cvCopy(srcImage, srcImg.Ptr, IntPtr.Zero);

                DenseHistogram hist;
                Image<Bgr, byte> histImage;

                //Hue Histogram
                int h_bins = 50;
                hist = Cal1DHsvHist(srcImage, h_bins);
                //draw histogram value to a new image
                histImage = Generate1DHistogramImgForDraw(hist);


                //HS Histogram
                /*
                int h_bins = 30, s_bins = 32;
                hist = Cal2DHsvHist(srcImage, h_bins, s_bins);
                //draw histogram value to a new image
                histImage = Generate2DHistogramImgForDraw(hist);
                */

                //顯示圖片
                ImageViewer histogarm_viewer = new ImageViewer(histImage, "Hitogram Image");
                histogarm_viewer.Show(this);
            }
        }

        /// < summary >
        /// 將IplImage指針轉換成Emgucv中的Image對象；
        /// 注意：這裡需要自己根據IplImage中的depth和nChannels來決定
        /// </ summary >
        /// < typeparam  name = "TColor" >Color type of this image (either Gray, Bgr, Bgra, Hsv, Hls, Lab, Luv, Xyz or Ycc)</ typeparam >
        /// < typeparam  name = "TDepth" >Depth of this image (either Byte, SByte, Single, double, UInt16, Int16 or Int32)</ typeparam >
        /// < param  name = "ptr" >IplImage指針</ param >
        /// < returns >返回Image對象</ returns >
        public static Image<TColor, TDepth> IplImagePointerToEmgucvImage<TColor, TDepth>(IntPtr ptr)
            where TColor : struct, IColor
            where TDepth : new()
        {
            MIplImage mi = (MIplImage)Marshal.PtrToStructure(ptr, typeof(MIplImage));
            return new Image<TColor, TDepth>(mi.width, mi.height, mi.widthStep, mi.imageData);
        }

        /// <summary>
        /// hue色相轉換成rgb color
        /// </summary>
        /// <param name="hue"></param>
        /// <returns></returns>
        private static MCvScalar HueToBgr(double hue)
        {
            int[] rgb = new int[3];
            int p, sector;
            int[,] sector_data = { { 0, 2, 1 }, { 1, 2, 0 }, { 1, 0, 2 }, { 2, 0, 1 }, { 2, 1, 0 }, { 0, 1, 2 } };
            hue *= 0.033333333333333333333333333333333f;
            sector = (int)Math.Floor(hue);
            p = (int)Math.Round(255 * (hue - sector));
            //p ^= sector & 1 ? 255 : 0;
            if ((sector & 1) == 1) p ^= 255;
            else p ^= 0;
            rgb[sector_data[sector, 0]] = 255;
            rgb[sector_data[sector, 1]] = 0;
            rgb[sector_data[sector, 2]] = p;
            MCvScalar scalar = new MCvScalar(rgb[2], rgb[1], rgb[0], 0);
            return scalar;
        }

        #region 繪製值方圖
        //////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// drawing hue color still have problem
        /// 1D值方圖(色調) 的繪製,使用emgucv提供的cvInvoke去調用opencv的函式
        /// 繪製與範例的值方圖一致目前先採用
        /// </summary>
        /// <param name="histDense"></param>
        /// <returns>回傳Image<Bgr, Byte>類別的圖源(值方圖以繪製進去),直接顯示即可</returns>
        public static Image<Bgr, Byte> Generate1DHistogramImgForDraw(DenseHistogram histDense)
        {
            try
            {
                float max_value = 0.0f;
                int[] a1 = new int[100];
                int[] b1 = new int[100];
                float ax = 0;
                int h_bins = histDense.BinDimension[0].Size;

                //1.使用Intptr
                // CvInvoke.cvGetMinMaxHistValue(histPtr, ref ax, ref max_value, a1, b1);

                //2.emgucv的DenseHistogram資料格式也可使用cvInvoke的openCV函式
                CvInvoke.cvGetMinMaxHistValue(histDense, ref ax, ref max_value, a1, b1);
                /* 取最大的顏色的位置 並換成RGB
                foreach (int index in a1)
                {
                    Console.WriteLine("location="+index+",H Color = "+ HueToBgr(index * 180.0d / h_bins));
                } 
                 * */
               
                //設定值方圖圖像顯示的寬高
                int height = 240;
                int width = 800;
                IntPtr hist_img = CvInvoke.cvCreateImage(new System.Drawing.Size(width, height), Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_8U, 3);
                CvInvoke.cvZero(hist_img);

               　//用來存放從Hsv轉回RGB圖像時用的空間
                //IntPtr hsv_color = CvInvoke.cvCreateImage(new System.Drawing.Size(1, 1), Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_8U, 3);
                //IntPtr rgb_color = CvInvoke.cvCreateImage(new System.Drawing.Size(1, 1), Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_8U, 3);
                int bin_w = width / (h_bins);

                for (int h = 0; h < h_bins; h++)
                {

                    /** 取得直方圖的統計資料，計算值方圖中的所有顏色中最高統計的數值，作為實際顯示時的圖像高 */
                    //
                    //取得值方圖的數值位置,以便之後存成檔案
                    //2.DenseHistogram
                    double bin_val = CvInvoke.cvQueryHistValue_1D(histDense, h);
                    int intensity = (int)System.Math.Round(bin_val * height / max_value);

                    /** 取得現在抓取的直方圖的hue顏色，並為了顯示成圖像可觀看，轉換成RGB色彩 */
                    CvInvoke.cvRectangle(hist_img, new System.Drawing.Point(h * bin_w, height),
                        new System.Drawing.Point((h + 1) * bin_w, height - intensity),
                        HueToBgr(h * 180.0d / h_bins), -1, Emgu.CV.CvEnum.LINE_TYPE.EIGHT_CONNECTED, 0);

                }

                /*
                 *使用openCV函式繪製
                CvInvoke.cvNamedWindow("Source");
                CvInvoke.cvShowImage("Source", this.srcImage);
                CvInvoke.cvNamedWindow("H-S Histogram");
                CvInvoke.cvShowImage("H-S Histogram", hist_img);
                CvInvoke.cvWaitKey(0);
                 * */

                /* 另一種轉換格式的方式 可行
                Image<Bgr, Byte> hist_emgu_img = new Image<Bgr, Byte>(new System.Drawing.Size(width, height));
                CvInvoke.cvCopy(hist_img, hist_emgu_img.Ptr, IntPtr.Zero);
                return hist_emgu_img;
                 * */
                return IplImagePointerToEmgucvImage<Bgr, Byte>(hist_img);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(ex.Message);
            }
        }

        /// <summary>
        /// 2D值方圖(色調與飽和度) 的繪製,使用emgucv提供的cvInvoke去調用opencv的函式
        /// 繪製與範例的值方圖一致目前先採用
        /// </summary>
        /// <param name="histDense"></param>
        /// <returns>回傳Image<Bgr, Byte>類別的圖源(值方圖以繪製進去),直接顯示即可</returns>
        public static Image<Bgr, Byte> Generate2DHistogramImgForDraw(DenseHistogram histDense)
        {
            try
            {
                float max_value = 0.0f;
                int[] a1 = new int[100];
                int[] b1 = new int[100];
                float ax = 0;
                int h_bins = histDense.BinDimension[0].Size;
                int s_bins = histDense.BinDimension[1].Size;

                //1.使用Intptr
                // CvInvoke.cvGetMinMaxHistValue(histPtr, ref ax, ref max_value, a1, b1);

                //2.emgucv的DenseHistogram資料格式也可使用cvInvoke的openCV函式
                CvInvoke.cvGetMinMaxHistValue(histDense, ref ax, ref max_value, a1, b1);

                //設定值方圖圖像顯示的寬高
                int height = 300;
                int width;
                //如果設定的bins超過視窗設定的顯示範圍,另外給予可以符合用額外的彈出視窗顯示的值,因為要同時看到h與s的bin值，顯示的圖像寬可能會太寬
                if (h_bins * s_bins > 800)
                {
                    width = h_bins * s_bins * 2;
                }
                else
                {
                    width = 800;
                }

                IntPtr hist_img = CvInvoke.cvCreateImage(new System.Drawing.Size(width, height), Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_8U, 3);
                CvInvoke.cvZero(hist_img);

                //用來存放從Hsv轉回RGB圖像時用的空間
                IntPtr hsv_color = CvInvoke.cvCreateImage(new System.Drawing.Size(1, 1), Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_8U, 3);
                IntPtr rgb_color = CvInvoke.cvCreateImage(new System.Drawing.Size(1, 1), Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_8U, 3);
                int bin_w = width / (h_bins * s_bins);

                for (int h = 0; h < h_bins; h++)
                {
                    for (int s = 0; s < s_bins; s++)
                    {
                        int i = h * s_bins + s;

                        /** 取得直方圖的統計資料，計算值方圖中的所有顏色中最高統計的數值，作為實際顯示時的圖像高 */
                        //
                        //取得值方圖的數值位置,以便之後存成檔案
                        //1.Intptr
                        //double bin_val = CvInvoke.cvQueryHistValue_2D(histPtr, h, s);

                        //2.DenseHistogram
                        double bin_val = CvInvoke.cvQueryHistValue_2D(histDense, h, s);
                        int intensity = (int)System.Math.Round(bin_val * height / max_value);

                        /** 取得現在抓取的直方圖的hue顏色，並為了顯示成圖像可觀看，轉換成RGB色彩 */
                        CvInvoke.cvSet2D(hsv_color, 0, 0, new Emgu.CV.Structure.MCvScalar(h * 180.0f / h_bins, s * 255.0f / s_bins, 255, 0));
                        CvInvoke.cvCvtColor(hsv_color, rgb_color, COLOR_CONVERSION.CV_HSV2BGR);
                        Emgu.CV.Structure.MCvScalar color = CvInvoke.cvGet2D(rgb_color, 0, 0);
                        CvInvoke.cvRectangle(hist_img, new System.Drawing.Point(i * bin_w, height), new System.Drawing.Point((i + 1) * bin_w, height - intensity), color, -1, Emgu.CV.CvEnum.LINE_TYPE.EIGHT_CONNECTED, 0);
                    }
                }

                /*
                 *使用openCV函式繪製
                CvInvoke.cvNamedWindow("Source");
                CvInvoke.cvShowImage("Source", this.srcImage);
                CvInvoke.cvNamedWindow("H-S Histogram");
                CvInvoke.cvShowImage("H-S Histogram", hist_img);
                CvInvoke.cvWaitKey(0);
                 * */
                return IplImagePointerToEmgucvImage<Bgr, Byte>(hist_img);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(ex.Message);
            }
        }
        #endregion



        #region 計算圖像直方圖
        /// <summary>
        /// 2D計算值方圖(色調與飽和度) ,使用emgucv提供的cvInvoke去調用opencv的函式
        /// </summary>
        private static DenseHistogram Cal2DHsvHist(IntPtr srcImage, int h_bins, int s_bins)
        {
            try
            {
                DenseHistogram histDense;
                int[] hist_size = new int[2] { h_bins, s_bins };
                IntPtr hsv = CvInvoke.cvCreateImage(CvInvoke.cvGetSize(srcImage), Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_8U, 3);
                IntPtr h_plane = CvInvoke.cvCreateImage(CvInvoke.cvGetSize(srcImage), Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_8U, 1);
                IntPtr s_plane = CvInvoke.cvCreateImage(CvInvoke.cvGetSize(srcImage), Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_8U, 1);
                IntPtr v_plane = CvInvoke.cvCreateImage(CvInvoke.cvGetSize(srcImage), Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_8U, 1);
                IntPtr[] planes = new IntPtr[2] { h_plane, s_plane };

                /** Hue的變化範圍 */
                float[] h_ranges = new float[2] { 0, h_max_range };

                /** 飽和度的變化範圍 */
                float[] s_ranges = new float[2] { 0, s_max_range };


                //轉換成Hsv色彩空間 
                CvInvoke.cvCvtColor(srcImage, hsv, Emgu.CV.CvEnum.COLOR_CONVERSION.CV_BGR2HSV);
                CvInvoke.cvSplit(hsv, h_plane, s_plane, v_plane, System.IntPtr.Zero); // 分離取出色相空到的影像資料


                //emgucv的DenseHistogram資料格式也可使用cvInvoke的openCV函式
                RangeF hRange = new RangeF(0f, h_max_range);       //H色調分量的變化範圍
                RangeF sRange = new RangeF(0f, s_max_range);       //S飽和度分量的變化範圍
                histDense = new DenseHistogram(hist_size, new RangeF[] { hRange, sRange });
                CvInvoke.cvCalcHist(planes, histDense, false, System.IntPtr.Zero);
                return histDense;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(ex.Message);
            }
        }

        /// <summary>
        /// 1D計算值方圖(色調與飽和度) ,使用emgucv提供的cvInvoke去調用opencv的函式 ok
        /// </summary>
        private static DenseHistogram Cal1DHsvHist(IntPtr srcImage, int h_bins)
        {
            try
            {
                DenseHistogram histDense;
                IntPtr hsv = CvInvoke.cvCreateImage(CvInvoke.cvGetSize(srcImage), Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_8U, 3);
                IntPtr h_plane = CvInvoke.cvCreateImage(CvInvoke.cvGetSize(srcImage), Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_8U, 1);

                /** Hue的變化範圍 */
                float[] h_ranges = new float[2] { 0, h_max_range };
                IntPtr[] h_plane_ptr = new IntPtr[] { h_plane };

                //轉換成Hsv色彩空間 
                CvInvoke.cvCvtColor(srcImage, hsv, Emgu.CV.CvEnum.COLOR_CONVERSION.CV_BGR2HSV);
                CvInvoke.cvSplit(hsv, h_plane, IntPtr.Zero, IntPtr.Zero, System.IntPtr.Zero); // 分离的单通道数组d


                //emgucv的DenseHistogram資料格式也可使用cvInvoke的openCV函式
                RangeF hRange = new RangeF(0f, h_max_range);       //H色調分量的變化範圍
                histDense = new DenseHistogram(h_bins, hRange);
                CvInvoke.cvCalcHist(h_plane_ptr, histDense, true, System.IntPtr.Zero);

                return histDense;
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(ex.Message);
            }
        }
        #endregion
       
    }
}
