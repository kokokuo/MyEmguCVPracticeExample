this sample is how to draw color histogram  by yourself
my article :http://www.dotblogs.com.tw/v6610688/archive/2014/02/06/emgucv_draw_histogram_color_histogram.aspx