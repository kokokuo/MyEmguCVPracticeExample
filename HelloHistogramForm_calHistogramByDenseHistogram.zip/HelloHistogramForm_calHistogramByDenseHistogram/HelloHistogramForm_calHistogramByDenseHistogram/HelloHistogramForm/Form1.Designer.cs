﻿namespace HelloHistogramForm
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.imgHistogramBox = new Emgu.CV.UI.HistogramBox();
            this.loadImgButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // imgHistogramBox
            // 
            this.imgHistogramBox.Location = new System.Drawing.Point(42, 66);
            this.imgHistogramBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.imgHistogramBox.Name = "imgHistogramBox";
            this.imgHistogramBox.Size = new System.Drawing.Size(360, 265);
            this.imgHistogramBox.TabIndex = 0;
            // 
            // loadImgButton
            // 
            this.loadImgButton.Location = new System.Drawing.Point(12, 12);
            this.loadImgButton.Name = "loadImgButton";
            this.loadImgButton.Size = new System.Drawing.Size(75, 23);
            this.loadImgButton.TabIndex = 1;
            this.loadImgButton.Text = "載入圖片";
            this.loadImgButton.UseVisualStyleBackColor = true;
            this.loadImgButton.Click += new System.EventHandler(this.loadImgButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(442, 343);
            this.Controls.Add(this.loadImgButton);
            this.Controls.Add(this.imgHistogramBox);
            this.Name = "Form1";
            this.Text = "HelloHistogramForm";
            this.ResumeLayout(false);

        }

        #endregion

        private Emgu.CV.UI.HistogramBox imgHistogramBox;
        private System.Windows.Forms.Button loadImgButton;
    }
}

