﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//EmguCV
using Emgu.CV;
using Emgu.Util;
using Emgu.CV.Util;
using Emgu.CV.UI;
using Emgu.CV.Structure;
using Emgu.CV.CvEnum;
using System.IO;
namespace HelloHistogramForm
{
    public partial class Form1 : Form
    {
        //取得專案執行黨所在的目錄=>System.Windows.Forms.Application.StartupPath
        //使用DirectoryInfo移動至上層
        DirectoryInfo dir;
        Image<Bgr, byte> loadImg;
        string imgPath;
        public Form1()
        {
            InitializeComponent();
            dir = new DirectoryInfo(System.Windows.Forms.Application.StartupPath);
        }


        private string loadImgFile()
        {
            OpenFileDialog dlg = new OpenFileDialog();
            //移動上層在指定下層路徑
            dlg.RestoreDirectory = true;
            dlg.InitialDirectory = dir.Parent.Parent.FullName + @"\ModelImages";
            dlg.Title = "Open Image File";
           
            // Set filter for file extension and default file extension
            dlg.Filter = "JPeg Image|*.jpg|Bitmap Image|*.bmp|Gif Image|*.gif|Png Image|*.png";

            // Display OpenFileDialog by calling ShowDialog method ->ShowDialog()
            // Get the selected file name and display in a TextBox
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK && dlg.FileName != null)
            {
                // Open document
                string filename = dlg.FileName;
                return filename;
            }
            else
            {
                return null;
            }

        }
        private DenseHistogram CalHistBlue()
        { 
            //計算Blue單通道
            int Bbin = 32; //切割量化的數量
            RangeF BRange = new RangeF(0,255);
            DenseHistogram blueHist = new DenseHistogram(Bbin, BRange);
            //參數一是要計算的顏色資料，這邊分割通道並取得Blue通道的顏色;依序[1]:Green->[2]:Red
            blueHist.Calculate(new IImage[] { loadImg.Split()[0] }, false, null);
            return blueHist;
        }

        private DenseHistogram CalHistBlueGreenHist() {
            //計算Blue-Green單通道
            int[] BGbins = { 16, 16 }; //切割量化的數量
            RangeF[] BGRanges = new RangeF[] { new RangeF(0, 255), new RangeF(0, 255) };
            DenseHistogram bgHist = new DenseHistogram(BGbins, BGRanges);
            //填入Blue-Green通道的顏色圖像
            bgHist.Calculate(new IImage[] { loadImg.Split()[0], loadImg.Split()[1] }, false, null);

            return bgHist;
        }

        private DenseHistogram CalHistHSHist() {
            //計算Hsv的H-S
            int[] HSbins = { 8, 16 }; //切割量化的數量{HBin,SBin}
            RangeF[] HSRanges = new RangeF[] { new RangeF(0, 180), new RangeF(0, 255) }; //H,S
            DenseHistogram hsHist = new DenseHistogram(HSbins, HSRanges);
            //填入H-S通道的顏色圖像
            hsHist.Calculate(new IImage[] { loadImg.Convert<Hsv, byte>().Split()[0], loadImg.Convert<Hsv, byte>().Split()[1] }, false, null);

            return hsHist;
        }

        private void loadImgButton_Click(object sender, EventArgs e)
        {

            imgPath = loadImgFile();
            loadImg = new Image<Bgr, byte>(imgPath);
            //1.使用HistogramViewer
            HistogramViewer.Show(CalHistBlue(), "Blue channel");　//image[0] 顯示Blue,bin = 32

            HistogramViewer.Show(CalHistBlueGreenHist(), "Blue-Green channel");　//會失敗,無法同時顯示多通道的統計

            //2.使用HistogramBox
            imgHistogramBox.AddHistogram("Blue histogram", Color.Blue, CalHistBlue()); //放入自己計算的值方圖資料
            imgHistogramBox.Refresh(); //更新資料
            imgHistogramBox.Show(); 
        }

        
    }
}
